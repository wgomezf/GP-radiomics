function T = create_tree(params)
p = 0.5;  % Initialization ramped half-and-half method
flag = true;
while flag
    if rand < p
        T = create_random_tree(tree,0,params.dmax,'full',params);
    else
        T = create_random_tree(tree,0,params.dmax,'grow',params);
    end
    flag = validate_tree(T,params);
end