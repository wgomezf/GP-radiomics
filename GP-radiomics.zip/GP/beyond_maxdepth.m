function S = beyond_maxdepth(S,T,n,idx,maxd)
str = sprintf('[%d,%d]',maxd,idx);
if T.isleaf(idx)
    S = S.addnode(n,str);
else
    [S,n] = S.addnode(n,str);
    idx = T.getchildren(idx);
    for i = 1:2
        S = beyond_maxdepth(S,T,n,idx(i),maxd-1);
    end
end