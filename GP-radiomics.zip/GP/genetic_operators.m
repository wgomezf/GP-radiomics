function [Fs,Ts] = genetic_operators(X,Y,Fpop,Tpop,opt,params)
switch opt
    case 1 % Mutation
        j1 = TournamentSelection(Fpop,params);
        T1 = Tpop(j1,:);
        r  = randi([1 params.f],1,1);
        T1{r} = sub_tree_mutation(T1{r},params);
        fit1 = evaluate_individual(X,Y,T1,params);
        % Recover previous solutions if there is an invalid solution
        if isnan(fit1)
            T1 = Tpop(j1,:); 
            fit1 = Fpop(j1);
        end
        fit2 = NaN;
        T2 = cell(1,params.f); 
    case 2 % Crossover
        % Select two parents
        j1 = 0; j2 = 0;
        f1 = 0; f2 = 0;
        c  = 0; % Counter to avoid infinite loop
        while ((j1 == j2) || (f1 == f2)) && (c <= 2*params.np) % Ensure two different parents with distinct fitness
            [j1,f1] = TournamentSelection(Fpop,params);
            [j2,f2] = TournamentSelection(Fpop,params); 
            c = c+1;
        end
        % Get parents
        T1 = Tpop(j1,:); 
        T2 = Tpop(j2,:);
        % Get random trees
        r1 = randi([1 params.f],1,1);
        r2 = randi([1 params.f],1,1);
        % Crossover
        [T1{r1},T2{r2}] = crossover(T1{r1},T2{r2},params);
        fit1 = evaluate_individual(X,Y,T1,params);
        fit2 = evaluate_individual(X,Y,T2,params);
        % Recover previous solutions if there is an invalid solution
        if isnan(fit1)
            T1 = Tpop(j1,:); 
            fit1 = Fpop(j1);
        end
        if isnan(fit2)
            T2 = Tpop(j2,:); 
            fit2 = Fpop(j2);
        end
end
Ts = cat(3,T1,T2);
Fs = cat(2,fit1,fit2);