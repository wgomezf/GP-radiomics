% ADAPTED GEOMETRIC SEMANTIC GENETIC PROGRAMMING FOR DIABETES AND
% BREAST CANCER CLASSIFICATION
function T = devolution(T,params)
term_set = params.term_set;
[list,~] = getList(T,params);
L = size(list,1);
if any(list(:,1)<0)
    tN = [];
    for i = 1:L
        if list(i,1)==1 && ~T.isleaf(list(i,2))
            idc = T.getchildren(list(i,2));
            Tdw = T.subtree(list(i,2));
            idh = Tdw.findleaves;
            term = cell(1,numel(idh));
            for j = 1:numel(idh)
                term{j} = Tdw.get(idh(j));
            end
            term = unique(term);
            if ~T.isleaf(idc(1)) && ~T.isleaf(idc(2))
                if numel(term) < 2
                    term = term_set;
                end
                idt = randperm(numel(term),2);
                T = T.set(idc(1),term{idt(1)});
                T = T.set(idc(2),term{idt(2)});
                tN = cat(2,tN,idc(1),idc(2));
            end
            if ~T.isleaf(idc(1))
                term = setdiff(term,{T.get(idc(2))});
                if numel(term) < 2
                    term = setdiff(term_set,{T.get(idc(2))});
                end
                idt = randperm(numel(term),1);
                T = T.set(idc(1),term{idt});
                tN = cat(2,tN,idc(1));
            end
            if ~T.isleaf(idc(2))
                term = setdiff(term,{T.get(idc(1))});
                if numel(term) < 2
                    term = setdiff(term_set,{T.get(idc(1))});
                end
                idt = randperm(numel(term),1);
                T = T.set(idc(2),term{idt});
                tN = cat(2,tN,idc(2));
            end
        end
    end
    %Remove nodes below the cut-off point
    while T.depth > params.dmax   
        idx = T.flatten;
        idx = idx{end,:};
        T = T.removenode(idx(1));
    end
end
%****************************************************************
function [list,S] = getList(T,params)
S = beyond_maxdepth(tree,T,0,1,params.dmax);
idx = S.flatten;
idx = cat(2,idx{:});
L = numel(idx);
list = zeros(L,2);
for i = 1:L
    list(i,:) = eval(S.get(idx(i)));
end
idx = list(:,1)<2;
list = list(idx,:);