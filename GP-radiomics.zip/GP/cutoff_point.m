function tN = cutoff_point(T,p)
idx = T.flatten;
idx = cat(2,idx{:});
L = length(idx);
w = zeros(1,L);
for i = 2:L
    if T.isleaf(idx(i))
        w(i) = p;
    else
        w(i) = 1-p;
    end
end
tN = randsample(idx,1,true,w);