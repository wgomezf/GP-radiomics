function Tout = sub_tree_mutation(Tin,params)
Tout = Tin;
while isequal(Tin,Tout) % Do not mutate with the same information
    % Create a mutant tree
    Tm = create_tree(params);
    % Get cut-off points to crossover
    t = cutoff_point(Tin,params.pcr);
    tm = cutoff_point(Tm,params.pcr);
    % Perform crossover between parent and mutant tree
    Tout = cross_trees(Tin,Tm,t,tm,params);
end