function X2 = GP_transform(X,T)
n = size(X,1);
f = numel(T);
X2 = zeros(n,f); % Array to save constructed features
for i = 1:f
    newFeat = tree2expression(T{i}); % Construct GP feature
    X2(:,i) = newFeat(X); % Save it
end