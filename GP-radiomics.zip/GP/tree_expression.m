% John R. Koza and Riccardo Poli. 
% A Genetic Programming Tutorial
% Figure 9. Typical interpreter for genetic programming
function expr = tree_expression(T,n)
    if T.isleaf(n)
        expr = T.get(n);
    else
        func  = T.get(n);
        child = T.getchildren(n);
        argl  = tree_expression(T,child(1));
        argr  = tree_expression(T,child(2));
        expr  = sprintf('%s(%s,%s)',func,argl,argr);
    end
end