function fit = evaluate_individual(X,Y,T,params)
warning off;
% Shuffle data
rd = randperm(params.n);
X  = X(rd,:);
Y  = Y(rd);
X2 = zeros(params.n,params.f); % Array to save constructed features
for i = 1:params.f
    flag = validate_tree(T{i},params); % Verify if tree is valid
    if flag
       fit = NaN;
       return;
    end
    newFeat = tree2expression(T{i}); % Construct GP feature
    X2(:,i) = newFeat(X); % Save it
end
feas = tree2original(T); % Get original features at trees' inputs
Win  = mnrfit(X(:,feas),Y); % Tain input LR model with original features
Wout = mnrfit(X2,Y); % Tain output LR model with GP features
if any(isnan(Win)) || any(isnan(Wout))
    fit = NaN;
else
    Pin  = mnrval(Win,X(:,feas));
    Pout = mnrval(Wout,X2);  
    Zin  = AUC(Pin(:,2),Y);
    Zout = AUC(Pout(:,2),Y);
    fit  = Zout/Zin; % Fitness function (AUC gain output-to-input)
end
%*********************************************************************
function z = AUC(Yp,Ytrue)
xi = Yp(Ytrue=='1');
xj = Yp(Ytrue=='0');
n0 = size(xi,1); 
n1 = size(xj,1);
[r,~] = tiedrank([xi;xj]);
s0 = sum(r(1:n0));
z = max(0.5,(s0-(n0*(n0+1)/2))/(n0*n1));