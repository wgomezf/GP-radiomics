function S = equal_subtrees(S,T,n,idx)
if T.isleaf(idx)
    S = S.addnode(n,false);
else
    idx = T.getchildren(idx);
    T1  = T.subtree(idx(1));
    T2  = T.subtree(idx(2));
    [S,n] = S.addnode(n,isequal(T1,T2));
    for i = 1:2
        S = equal_subtrees(S,T,n,idx(i));
    end
end