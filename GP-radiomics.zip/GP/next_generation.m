function [Fpop,Tpop] = next_generation(Fpop,Tpop,Foff,Toff)
% Elitism
[Felit,id] = max(Fpop); % Best
Telit  = Tpop(id,:);
% Next generation
Fpop = cat(1,Foff(:,1),Foff(:,2));
Tpop = cat(1,Toff(:,:,1),Toff(:,:,2));
idx  = isnan(Fpop);
Fpop(idx)   = [];
Tpop(idx,:) = [];
% Replace current worst with previous best
[Fmin,id] = min(Fpop);
if Felit > Fmin
    Fpop(id,:) = Felit;
    Tpop(id,:) = Telit;
end