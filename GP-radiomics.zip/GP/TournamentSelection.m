function [i,f] = TournamentSelection(F,params)
S = randperm(params.np,params.tsze);
[f,j] = max(F(S));
i = S(j);