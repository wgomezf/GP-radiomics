function flag = validate_tree(T,params)
f1 = equal_subtrees(tree,T,0,1); % Ensure not equal subtrees
f2 = T.depth < params.dmin; % Ensure minumum depth
flag = f1.any | f2;