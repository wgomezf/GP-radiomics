% Alain Pétrowski and Sana Ben-Hamida. Evolutionary Algorithms, 1st Edition.
% Chapter 6: Genetic Programming for Machine Learning, Algorithm 1, p. 190
function T = create_random_tree(T,n,max_d,met,params)
    func_set = params.func_set;
    term_set = params.term_set;
    nterm = numel(term_set);
    nfunc = numel(func_set);
    if max_d < params.dmax
        prop  = nterm/(nterm + nfunc);
    else
        prop = 0.0; % Ensure trees with at least 1-level depth
    end
    if (max_d==0) || (strcmpi(met,'grow') && (rand < prop))
        term = choose_random_element(term_set);
        T = T.addnode(n,term);
    else
        func = choose_random_element(func_set);
        [T,n] = T.addnode(n,func);
        for i = 1:2
            T = create_random_tree(T,n,max_d-1,met,params);
        end
    end
end