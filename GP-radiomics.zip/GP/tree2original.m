function feas = tree2original(T)
feas = [];
for j = 1:size(T,2)
    id = T{j}.findleaves;
    for i = 1:numel(id)
        fea = T{j}.get(id(i));
        if contains(fea,'X')
            i1 = strfind(fea,',');
            i2 = strfind(fea,')');
            feas = cat(2,feas,str2double(fea(i1+1:i2-1)));
        end
    end
end
feas = unique(feas);