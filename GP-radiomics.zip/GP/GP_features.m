function [Fbest,Tbest,curves] = GP_features(X,Y,ntrees,dmax)
% Parameters
params.n  = size(X,1);          % Number of instances
params.d  = size(X,2);          % Number of features (terminals)
params.c  = unique(Y);          % Classes
params.nc = numel(params.c);    % Number of classes
params.f  = ntrees;             % Number of trees (constructed features)
params.dmin = dmax;             % Minimum tree depth
params.dmax = dmax;             % Maximum tree depth
params.np = 50;                 % Population size
params.gmax = 500;             % Maximum number of generations
params.tsze = 5;                % Tournament size
params.pcr = 0.01;               % Probability of crossover (select terminals)
params.prb = [0.1 0.9];         % Probabilities:  mutation, crossover
% Define terminal and function sets
[params.term_set,params.func_set] = primitives(params);
% Initial population
Tpop = cell(params.np,params.f);
Fpop = zeros(params.np,1);
parfor i = 1:params.np % Paralellize individual evaluation (Requires Parallel Toolbox)
    [Fpop(i),Tpop(i,:)] = create_individual(X,Y,params);
end
% Get best individual
[Fbest,Tbest,Nbest] = update_best(0,[],0,Fpop,Tpop);
fprintf('g: %d - Fitness: %0.4f - Nodes: %d\n',0,Fbest,Nbest);
% GP loop
curves = zeros(params.gmax+1,2);
curves(1,:) = [mean(Fpop) Fbest];
for g = 1:params.gmax
    % Get genetic operators
    [opt,n] = get_operator(params);
    % Apply genetic operators: mutation and crossover
    Toff = cell(n,params.f,2);
    Foff = zeros(n,2);
    parfor i = 1:n % Paralellize individual evaluation
        [Foff(i,:),Toff(i,:,:)] = genetic_operators(X,Y,Fpop,Tpop,opt(i),params);
    end
    % Update next generation
    [Fpop,Tpop] = next_generation(Fpop,Tpop,Foff,Toff);
    % Update best on validation
    [Fbest,Tbest,Nbest] = update_best(Fbest,Tbest,Nbest,Fpop,Tpop);
    % Save curves
    curves(g+1,:) = [mean(Fpop) Fbest];
    % Print
    fprintf('g: %d - Fitness: %0.4f - Nodes: %d\n',g,Fbest,Nbest);
end