function [T1c,T2c] = crossover(T1,T2,params)
T1c = T1;
T2c = T2;
while isequal(T1,T1c) || isequal(T2,T2c) % Do not cross the same information
    % Get cut-off points to crossover
    tN1 = cutoff_point(T1,params.pcr);
    tN2 = cutoff_point(T2,params.pcr);
    % Perform crossover on first tree
    T1c = cross_trees(T1,T2,tN1,tN2,params);
    % Perform crossover on second tree
    T2c = cross_trees(T2,T1,tN2,tN1,params);
end