function [Fbest,Tbest,Nbest] = update_best(Fbest,Tbest,Nbest,Fpop,Tpop)
[~,id] = max(Fpop);
Tmax = Tpop(id,:);
Nmax = 0;
for i = 1:size(Tmax,2) % Count number of nodes
    Nmax = Nmax + Tmax{i}.nnodes; 
end
if (Fpop(id) > Fbest)
    Fbest = Fpop(id,:);
    Tbest = Tpop(id,:);
    Nbest = Nmax;
end