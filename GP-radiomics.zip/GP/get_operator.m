function [pr,n] = get_operator(params) 
np = 0;
pr = [];
while np < params.np
    if np==params.np-1 
        opt = randi([1 2],1,1);
    else
        opt = randsample(1:2,1,true,params.prb);
    end
    pr = cat(2,pr,opt);
    switch opt
        case 1 % mutation
            np = np+1;
        case 2 % crossover
            np = np+2;
    end
end
n = numel(pr);