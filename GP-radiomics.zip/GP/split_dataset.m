function [Xtr,Ytr,Xtt,Ytt] = split_dataset(X,Y,p)
% Split into training and test sets
Y = categorical(Y);
[tr,tt]  = crossvalind('HoldOut',Y,p);
Xtr = X(tr,:); % Training features
Ytr = Y(tr);    % Class labels: 0 - suvivor, 1 - non-survivor
Xtt = X(tt,:); % Test features
Ytt = Y(tt);   % Class labels