function T1 = cross_trees(T1,T2,tN1,tN2,params)
% Get lower sub-tree from T2 below the cut-off point
T2dw = T2.subtree(tN2);
% Remove nodes from T1 below the cut-off point
idx = T1.getchildren(tN1);
while ~isempty(idx)
    T1 = T1.removenode(idx(1));
    idx = T1.getchildren(tN1);
end
% Paste T2 subtree in T1 at the cut-off point
T1  = T1.set(tN1,T2dw.get(1));
T1  = T1.graft(tN1,T2dw);
idx = T1.getchildren(tN1);
T1  = T1.removenode(idx);
T1  = devolution(T1,params);