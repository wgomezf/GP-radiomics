function equ = tree2expression(T)
    expr = tree_expression(T,1);
    equ = str2func(['@(X)',expr]);
end