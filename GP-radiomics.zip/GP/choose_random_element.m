function expr = choose_random_element(set_)
i = randi([1 numel(set_)]);
expr = set_{i};