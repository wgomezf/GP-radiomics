function [term_set, func_set] = primitives(params)
% Terminals (features)
term_set = cell(1,params.d);
for i = 1:params.d
    term_set{i} = sprintf('X(:,%d)',i);
end
% Functions
func_set = {'ADD' 'SUB' 'MUL' 'DIV' 'MIN' 'MAX'}; %   