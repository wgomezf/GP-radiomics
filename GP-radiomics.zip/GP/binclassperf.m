% Yt - True label
% Yp - Predicted label
% Sp - Predicted score
function [Out,C] = binclassperf(Yt,Yp,Sp)
    pL = Yt == '1';
    nL = Yt == '0';
    TP = sum(Yp(pL)=='1');
    TN = sum(Yp(nL)=='0');
    FP = sum(Yp(nL)=='1');
    FN = sum(Yp(pL)=='0');
    C   = [TP FN;FP TN]; % Confusion matrix
    ACC = (TP+TN)/(TP+TN+FP+FN); % Accuracy     
    PRE = TP/(TP+FP); % precision
    SEN = TP/(TP+FN); % sensitivity or recall
    SPE = TN/(FP+TN); % specificity
    A   = AUC(Sp,Yt);
    Out = [ACC,PRE,SEN,SPE,A];
end
%********************************************************************
function z = AUC(Yp,Ytrue)
xi = Yp(Ytrue=='1');
xj = Yp(Ytrue=='0');
n0 = size(xi,1); 
n1 = size(xj,1);
[r,~] = tiedrank([xi;xj]);
s0 = sum(r(1:n0));
z = (s0-(n0*(n0+1)/2))/(n0*n1);
end