function [fit,T] = create_individual(X,Y,params)
fit = NaN;
while isnan(fit)
    T = cell(1,params.f);
    for i = 1:params.f
        T{i} = create_tree(params);
    end
    fit = evaluate_individual(X,Y,T,params);
end