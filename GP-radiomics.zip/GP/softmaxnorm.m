function [G,Stats] = softmaxnorm(F,Stats)
if nargin == 1
    m = mean(F,1);
    s = std(F,[],1)+1e-9;
    Stats.Mean = m;
    Stats.Std  = s;
elseif nargin == 2
    m = Stats.Mean;
    s = Stats.Std;
end
FM = bsxfun(@minus,F,m);
DV = bsxfun(@rdivide,FM,s);
E  = exp(-DV);
G  = (1-E)./(1+E); 