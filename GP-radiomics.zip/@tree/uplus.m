function obj = uplus(obj)
%% +  Unary plus
    obj = obj.treefun(@uplus);
end