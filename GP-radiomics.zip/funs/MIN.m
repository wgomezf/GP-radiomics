function z = MIN(x,y)
z = min(x,y); % linear