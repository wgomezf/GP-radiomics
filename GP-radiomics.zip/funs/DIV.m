function z = DIV(x,y)
id = abs(y)<1e-4;
z = x./y;
z(id) = 1.0;   % Protected