function z = SUB(x,y)
z = x-y;