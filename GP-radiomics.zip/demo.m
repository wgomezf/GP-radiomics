clearvars; close all; clc;

addpath(fullfile(pwd,'funs'),fullfile(pwd,'GP'));

% Load LUNG1 dataset
load('nsclc.mat');

% Split into training and test sets
[Xtr,Ytr,Xtt,Ytt] = split_dataset(X,Y,0.2);

% Feature normalization with softmax
[Xtr,Stats] = softmaxnorm(Xtr);
Xtt = softmaxnorm(Xtt,Stats);

% Run GP to construct features
ntrees = 2; % Number of trees or constructed features
dmax = 3; % Maximum tree depth
[Fbest,Tbest,Curves] = GP_features(Xtr,Ytr,ntrees,dmax);

% Print trees
for i = 1:ntrees
    disp(Tbest{i}.tostring)
    disp(' ')
end

% Map original features to GP features
X2tr = GP_transform(Xtr,Tbest);
X2tt = GP_transform(Xtt,Tbest);
% Tain LR model with GP features
W = mnrfit(X2tr,Ytr);
Prb = mnrval(W,X2tt);
Ypp = categorical(double(Prb(:,2)>0.5));
% Classification performance
[Out,CM] = binclassperf(Ytt,Ypp,Prb(:,2));
fprintf("GP features performance: \n");
fprintf("AUC = %0.3f\n",Out(5));
fprintf("Accuracy = %0.3f\n",Out(1));
fprintf("Precision = %0.3f\n",Out(2));
fprintf("Sensitivity = %0.3f\n",Out(3));
fprintf("Specificity = %0.3f\n",Out(4));